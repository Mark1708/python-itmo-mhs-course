# simple_latex_generator

Simple Python Library for working with LaTex
- Generate Tex file from Python Code
  - Tables
  - Graphics
- Save as Tex or PDF

~~Made with love by Mark~~ 
**Made without love by Mark (because Java is the Best)**